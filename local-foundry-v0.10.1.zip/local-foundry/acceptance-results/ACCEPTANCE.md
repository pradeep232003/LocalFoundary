# Local Foundry v0.10.1 acceptance

Overall: **incomplete**

- **passed** — Unit and behavioral regression suite
- **blocked** — PostgreSQL storage pass (builder and accounts kit): Set FOUNDRY_TEST_DATABASE_URL to a scratch database (the user needs CREATEDB) to run the suite against real PostgreSQL.
- **passed** — Builder React production build
- **passed** — Starter React production build
- **passed** — Accounts React production build
- **passed** — Frontend render smoke (App and extracted panels)
- **passed** — Accessibility scan (builder states)
- **passed** — Accessibility scan (accounts states)
- **passed** — Mobile wrapper generator
- **passed** — App icons and store screenshots
- **blocked** — Signed Android build (APK/AAB): No Android SDK on this host. Install it, set ANDROID_HOME, then follow MOBILE.md.
- **blocked** — Signed iOS build (IPA): Use a Mac or macOS CI runner with signing credentials; see MOBILE.md.
- **blocked** — macOS smoke and UI capture: Requires the target Mac, Docker Desktop and Google Chrome.
- **blocked** — Windows 11 / WSL2 runtime and UI capture: Run Windows.ps1 Start and Windows.ps1 Test on the target Windows 11 laptop.
- **blocked** — Native launcher, preview access and physically disconnected restart: Follow WINDOWS.md on Windows, or the packaged-app procedure on Mac: disable networking, restart, edit with a cached local model and verify preview data survives.
- **blocked** — Real PostgreSQL, browser journeys, recovery and release: Docker unavailable or real Docker acceptance not selected; run --mode mac or --mode windows on the target host.
- **blocked** — Real model Accounts build: Requires a running builder and configured model. --mode live authorizes model calls; cloud providers may charge.
- **blocked** — Real Stripe checkout, email delivery and outbound webhook: Requires your staging/test provider accounts and a reachable HTTPS app. Follow PROVIDER-ACCEPTANCE.md; no provider credentials supplied to this harness.
- **blocked** — Deployment-host staging, encrypted backup restore and external alert delivery: Run the exported OPERATIONS.md acceptance on the actual deployment and independent monitoring hosts.
- **passed** — Ruff source checks
- **passed** — Frontend formatting check
- **passed** — Store screenshot runner syntax

Python: 300 passed, 86 skipped. Native SDK, device and target-host checks remain blocked.
UI/a11y checks compare against existing baselines; they are not a clean accessibility audit.
