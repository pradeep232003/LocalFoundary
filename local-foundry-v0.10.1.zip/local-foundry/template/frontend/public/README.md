Place local static assets here. This starter accepts text and SVG files.

